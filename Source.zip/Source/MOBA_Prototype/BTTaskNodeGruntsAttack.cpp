// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTaskNodeGruntsAttack.h"

EBTNodeResult::Type UBTTaskNodeGruntsAttack::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{

	return EBTNodeResult::Type();

}
