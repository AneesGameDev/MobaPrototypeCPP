// Copyright Epic Games, Inc. All Rights Reserved.

#include "MOBA_Prototype.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, MOBA_Prototype, "MOBA_Prototype" );
